"""Assess proposed A–G biosphere corrections without writing inventory changes.

The technosphere is fixed, so each exact score change is C * delta(B) * A^-1 * f.
Every proposal is evaluated alone and all proposals are then evaluated together.
"""

import argparse
import csv
import hashlib
import json
import pickle
import sqlite3
import time
from collections import defaultdict
from pathlib import Path


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def write_csv(path, rows):
    if not rows:
        return
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def identity(row):
    return row["name"], row.get("reference product", row.get("product")), row["location"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    started = time.perf_counter()
    root = args.output
    root.mkdir(parents=True, exist_ok=True)
    metadata = json.loads((args.baseline / "metadata.json").read_text())
    producers = read_csv(args.baseline / "refined_producers.csv")
    saved_rows = read_csv(args.baseline / "refined_producers_all_indicators.csv")
    saved = {identity(r): r for r in saved_rows}
    indicators = sorted(set(saved_rows[0]) - {"name", "product", "location"})

    import bw2calc as bc
    import bw2data as bd
    import numpy as np
    from scipy import sparse
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill

    bd.projects.set_current(metadata["project"])
    database = metadata["database"]
    database_path = Path(bd.Database(database).filepath_processed())
    fingerprint = hashlib.sha256(database_path.read_bytes()).hexdigest()
    assert fingerprint == metadata["database_fingerprints"][database]
    connection = sqlite3.connect(
        (Path(bd.projects.dir) / "lci/databases.db").as_uri() + "?mode=ro", uri=True
    )
    datasets, node_ids, exchanges = {}, {}, defaultdict(list)
    for node_id, code, raw in connection.execute(
        'SELECT id,code,data FROM activitydataset WHERE "database"=?', (database,)
    ):
        datasets[code] = pickle.loads(raw)
        node_ids[code] = node_id
    for code, raw in connection.execute(
        "SELECT output_code,data FROM exchangedataset WHERE output_database=?", (database,)
    ):
        exchanges[code].append(pickle.loads(raw))
    flows = {}
    for node_id, code, raw in connection.execute(
        'SELECT id,code,data FROM activitydataset WHERE "database"=?', (metadata["biosphere"],)
    ):
        flow = pickle.loads(raw)
        if tuple(flow.get("categories", ())) == ("natural resource", "in ground") and flow.get("unit") == "kilogram":
            assert flow["name"] not in flows, flow["name"]
            flows[flow["name"]] = (node_id, code)
    connection.close()
    codes_by_identity = {identity(d): code for code, d in datasets.items()}
    assert len(codes_by_identity) == len(datasets)

    lca = bc.LCA({node_ids[producers[0]["code"]]: 1}, ("RELICS", "metals extraction", indicators[0]))
    lca.lci(factorize=True)
    original_b = lca.biosphere_matrix.copy()
    original_a = lca.technosphere_matrix.copy()
    cf = []
    for name in indicators:
        lca.switch_method(("RELICS", "metals extraction", name))
        cf.append(lca.characterization_matrix.diagonal())
    cf = np.asarray(cf)

    # patch tuples refer only to elementary exchanges, not provider quantities.
    patches = {fix: [] for fix in "ABCDEFG"}
    modifications = []
    focal = {fix: set() for fix in patches}
    def eligible(name, product):
        return [code for code, d in datasets.items() if d["name"] == name and d["reference product"] == product and d.get("unit") == "kilogram"]

    def change(fix, code, element, new_amount):
        flow_id, flow_code = flows[element]
        old_amount = sum(float(e["amount"]) for e in exchanges[code]
                         if e["type"] == "biosphere" and tuple(e["input"]) == (metadata["biosphere"], flow_code))
        row = lca.dicts.biosphere[flow_id]
        col = lca.dicts.activity[node_ids[code]]
        assert np.isclose(original_b[row, col], old_amount, rtol=1e-7, atol=1e-10)
        if old_amount == new_amount:
            return
        patches[fix].append((row, col, new_amount - old_amount))
        d = datasets[code]
        modifications.append({"fix": fix, "name": d["name"], "product": d["reference product"],
                              "location": d["location"], "element": element,
                              "before_direct_resource": old_amount, "after_direct_resource": new_amount})

    atomic = {"O": 15.999, "Sb": 121.76, "S": 32.06, "As": 74.921595,
              "Na": 22.98976928, "Li": 6.94, "C": 12.011,
              "Cerium": 140.116, "Dysprosium": 162.5, "Erbium": 167.259,
              "Europium": 151.964, "Gadolinium": 157.25, "Holmium": 164.93033,
              "Lanthanum": 138.90547, "Lutetium": 174.9668, "Neodymium": 144.242,
              "Praseodymium": 140.90766, "Samarium": 150.36, "Terbium": 158.92535,
              "Thulium": 168.93422, "Ytterbium": 173.045, "Yttrium": 88.90584}
    for code in eligible("stibnite mine operation and beneficiation", "stibnite concentrate"):
        change("A", code, "Antimony", .7 * (2 * atomic["Sb"]) / (2 * atomic["Sb"] + 3 * atomic["S"]))
    for fix, product, element in [("B", "copper, cathode", "Copper"), ("C", "silver", "Silver")]:
        for code in eligible("primary zinc production from concentrate", product):
            inputs = [e for e in exchanges[code] if e["type"] == "technosphere" and e["amount"] > 0]
            primary = [e for e in inputs if e.get("product") == "zinc concentrate"]
            assert primary and sum(e["amount"] for e in primary) >= 1
            target_inputs = [e for e in inputs if element.lower() in (e.get("product") or "").lower()]
            assert sum(e["amount"] for e in target_inputs if e.get("unit") == "kilogram") < 1
            for e in [*primary, *target_inputs]:
                assert (e["name"], e["product"], e["location"]) in codes_by_identity
            change(fix, code, element, 1)
            focal[fix].add(code)
    lithium_fraction = 2 * atomic["Li"] / (2 * atomic["Li"] + atomic["C"] + 3 * atomic["O"])
    for name in ("lithium carbonate production, from concentrated brine", "lithium carbonate production, from spodumene"):
        for code in eligible(name, "lithium carbonate"):
            change("D", code, "Lithium", lithium_fraction)
    for code in eligible("sodium arsenide production from Imperial smelting furnace", "sodium arsenide"):
        change("E", code, "Arsenic", atomic["As"] / (3 * atomic["Na"] + atomic["As"]))
    for name in ("silicon production, metallurgical grade", "silicon production, metallurgical grade, photovoltaic supply chain"):
        for code in eligible(name, "silicon, metallurgical grade"):
            assert any(e["type"] == "technosphere" and e.get("product") == "silica sand" and e["amount"] > 0 for e in exchanges[code])
            change("F", code, "Silicon", 1)
    rare_earths = {element for element in atomic if len(element) > 2}
    oxide_codes = defaultdict(list)
    oxide_name = "rare earth oxides production, from rare earth carbonate concentrate"
    for element in sorted(rare_earths):
        oxide_codes[element] = eligible(oxide_name, element.lower() + " oxide")
        assert oxide_codes[element], element
        n, oxygen = {"Cerium": (1, 2), "Praseodymium": (6, 11), "Terbium": (4, 7)}.get(element, (2, 3))
        fraction = n * atomic[element] / (n * atomic[element] + oxygen * atomic["O"])
        for code in oxide_codes[element]:
            change("G", code, element, fraction)
    carrier_codes = eligible("rare earth element mine operation and beneficiation, ion adsorption clays", "rare earth carbonate concentrate")
    assert len(carrier_codes) == 2
    for code in carrier_codes:
        for element in rare_earths:
            change("G", code, element, 0)
    for producer in producers:
        metal = producer["metal"]
        fix = {"Antimony": "A", "Lithium": "D", "Arsenic": "E", "Silicon": "F",
               "Dysprosium": "G", "Holmium": "G", "Neodymium": "G", "Praseodymium": "G", "Terbium": "G"}.get(metal)
        if fix:
            focal[fix].add(producer["code"])
    focal["combined"] = set.union(*focal.values())
    deltas = {}
    for fix, entries in patches.items():
        assert entries, fix
        ii, jj, vv = zip(*entries)
        deltas[fix] = sparse.coo_matrix((vv, (ii, jj)), shape=original_b.shape).tocsr()
    deltas["combined"] = sum(deltas.values(), sparse.csr_matrix(original_b.shape))
    effects = {fix: sparse.csr_matrix(cf) @ delta for fix, delta in deltas.items()}
    write_csv(root / "direct_resource_changes.csv", modifications)
    print("PATCHES", {fix: len(entries) for fix, entries in patches.items()}, flush=True)

    baseline = np.empty((len(producers), len(indicators)))
    after = {fix: np.empty_like(baseline) for fix in deltas}
    checks, full_rows, own_rows, offdiag = [], [], [], []
    max_difference = 0
    for position, producer in enumerate(producers):
        node_id = node_ids[producer["code"]]
        lca.redo_lci({node_id: 1})
        supply = lca.supply_array.copy()
        before = np.asarray(cf @ (original_b @ supply)).ravel()
        saved_values = np.array([float(saved[identity(producer)][name]) for name in indicators])
        assert np.allclose(before, saved_values, rtol=1e-8, atol=1e-10), identity(producer)
        max_difference = max(max_difference, float(np.max(abs(before - saved_values))))
        baseline[position] = before
        own_col = indicators.index(producer["metal"])
        for fix, effect in effects.items():
            difference = np.asarray(effect @ supply).ravel()
            values = before + difference
            assert np.isfinite(values).all() and (values >= -1e-8).all()
            after[fix][position] = values
            if producer["code"] not in focal[fix]:
                continue
            own_rows.append({"fix": fix, "metal": producer["metal"], "name": producer["name"],
                             "product": producer["product"], "location": producer["location"],
                             "before": before[own_col], "after": values[own_col],
                             "offdiagonal_changed_indicators": int(sum(abs(difference[k]) > 1e-9 for k in range(len(indicators)) if k != own_col))})
            for k, indicator in enumerate(indicators):
                record = {"fix": fix, "metal": producer["metal"], "name": producer["name"],
                          "product": producer["product"], "location": producer["location"],
                          "indicator": indicator, "own_element": k == own_col,
                          "before": before[k], "after": values[k], "difference": difference[k]}
                full_rows.append(record)
                if k != own_col and abs(difference[k]) > 1e-9:
                    offdiag.append(record)
            # Independently patch the complete biosphere matrix and use normal LCIA.
            if fix != "combined" and (position == 0 or producer["code"] in focal[fix]):
                lca.biosphere_matrix = (original_b + deltas[fix]).tocsr()
                lca.redo_lci({node_id: 1})
                reference = np.asarray(cf @ np.asarray(lca.inventory.sum(axis=1)).ravel()).ravel()
                assert np.allclose(reference, values, rtol=1e-8, atol=1e-9)
                lca.switch_method(("RELICS", "metals extraction", producer["metal"]))
                lca.lcia()
                assert np.isclose(lca.score, values[own_col], rtol=1e-8, atol=1e-9)
                checks.append({"fix": fix, "name": producer["name"], "location": producer["location"],
                               "max_all_indicator_difference": float(np.max(abs(reference - values))),
                               "normal_lcia_difference": abs(lca.score - values[own_col])})
                lca.biosphere_matrix = original_b
        assert np.allclose(after["combined"][position] - before,
                           sum(after[fix][position] - before for fix in patches), rtol=1e-8, atol=1e-9)
        if position % 40 == 0:
            print(f"SCORED {position + 1}/{len(producers)}", flush=True)
    assert (lca.technosphere_matrix != original_a).nnz == 0
    assert (lca.biosphere_matrix != original_b).nnz == 0
    assert hashlib.sha256(database_path.read_bytes()).hexdigest() == fingerprint

    write_csv(root / "focal_rows_all_indicators.csv", full_rows)
    write_csv(root / "focal_own_element.csv", own_rows)
    write_csv(root / "focal_offdiagonal_changes.csv", offdiag)
    write_csv(root / "numerical_checks.csv", checks)
    workbook = Workbook()
    workbook.remove(workbook.active)
    summary = []
    for fix in deltas:
        difference = after[fix] - baseline
        changed = abs(difference) > 1e-9
        summary.append({"fix": fix, "changed_datasets": int(changed.any(axis=1).sum()),
                        "changed_indicators": "; ".join(name for k, name in enumerate(indicators) if changed[:, k].any()),
                        "changed_pairs": int(changed.sum()), "largest_absolute_change": float(abs(difference).max()),
                        "within_5_percent": int(sum(abs(after[fix][i, indicators.index(p['metal'])] - 1) <= .05 for i, p in enumerate(producers))),
                        "within_10_percent": int(sum(abs(after[fix][i, indicators.index(p['metal'])] - 1) <= .1 for i, p in enumerate(producers)))})
    write_csv(root / "fix_summary.csv", summary)
    for stage, matrix in [("before", baseline), *after.items()]:
        wide = [{"metal": producer["metal"], "name": producer["name"], "product": producer["product"],
                 "location": producer["location"], **dict(zip(indicators, matrix[i]))}
                for i, producer in enumerate(producers)]
        write_csv(root / f"{stage}_all_indicators.csv", wide)
        sheet = workbook.create_sheet("Before" if stage == "before" else f"{stage} after")
        fields = list(wide[0])
        sheet.append(fields)
        for row in wide:
            sheet.append([row[k] for k in fields])
        sheet.freeze_panes = "E2"
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.fill = PatternFill("solid", fgColor="193C61")
            cell.font = Font(color="FFFFFF", bold=True)
        for col, width in [("A", 18), ("B", 75), ("C", 38), ("D", 24)]:
            sheet.column_dimensions[col].width = width
        for row in sheet.iter_rows(min_row=2, min_col=5):
            for cell in row:
                cell.number_format = "0.000000E+00"
    for title, records in [("Fix summary", summary), ("Own element comparison", own_rows), ("Offdiagonal changes", offdiag)]:
        sheet = workbook.create_sheet(title)
        fields = list(records[0])
        sheet.append(fields)
        for row in records:
            sheet.append([row[k] for k in fields])
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
    workbook.save(root / "whole_row_assessment.xlsx")
    result = {"analysis": "exact isolated biosphere-matrix sensitivity; not a premise production implementation",
              "baseline": str(args.baseline), "database": database, "project": metadata["project"],
              "database_fingerprint": fingerprint, "saved_database_unchanged": True,
              "technosphere_matrix_unchanged": True, "saved_biosphere_matrix_unchanged": True,
              "functional_unit": "1 kg reference product", "producers": len(producers), "indicators": len(indicators),
              "fixes": list(patches), "combined_is_sum_of_individual_effects": True,
              "baseline_max_absolute_score_difference": max_difference,
              "independent_checks": len(checks),
              "independent_max_difference": max(r["max_all_indicator_difference"] for r in checks),
              "patch_counts": {fix: len(entries) for fix, entries in patches.items()},
              "oxide_formula_conventions": "CeO2, Pr6O11, Tb4O7; other carbonate-route single-element oxides M2O3",
              "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "seconds": time.perf_counter() - started}
    (root / "metadata.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
