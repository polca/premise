"""Package the whole-row sensitivity assessment, including an offline explorer."""

import argparse
import csv
import html
import json
import zipfile
from pathlib import Path


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    root = parser.parse_args().directory
    before = read_csv(root / "before_all_indicators.csv")
    stages = {fix: read_csv(root / f"{fix}_all_indicators.csv") for fix in [*"ABCDEFG", "combined"]}
    identity = lambda r: (r["name"], r["product"], r["location"])
    indicators = sorted(set(before[0]) - {"metal", "name", "product", "location"})
    changes = read_csv(root / "direct_resource_changes.csv")
    uncovered = sorted({r["element"] for r in changes if r["fix"] == "G"} - set(indicators))
    metadata_path = root / "metadata.json"
    metadata = json.loads(metadata_path.read_text())
    metadata["transferred_rare_earths_without_relics_indicator"] = uncovered
    metadata_path.write_text(json.dumps(metadata, indent=2))
    all_changes = []
    for fix, rows in stages.items():
        assert [identity(r) for r in rows] == [identity(r) for r in before]
        for old, row in zip(before, rows):
            for indicator in indicators:
                difference = float(row[indicator]) - float(old[indicator])
                if abs(difference) > 1e-9:
                    all_changes.append({"fix": fix, "metal": row["metal"], "name": row["name"],
                                        "product": row["product"], "location": row["location"],
                                        "indicator": indicator, "own_element": indicator == row["metal"],
                                        "before": float(old[indicator]), "after": float(row[indicator]),
                                        "difference": difference})
    with (root / "all_changed_pairs.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(all_changes[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(all_changes)

    from openpyxl import load_workbook
    workbook = load_workbook(root / "whole_row_assessment.xlsx")
    if "All changed pairs" in workbook.sheetnames:
        del workbook["All changed pairs"]
    sheet = workbook.create_sheet("All changed pairs")
    fields = list(all_changes[0])
    sheet.append(fields)
    for row in all_changes:
        sheet.append([row[k] for k in fields])
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions
    workbook.save(root / "whole_row_assessment.xlsx")

    conclusions = {
        "A": "Corrects the documented Sb content: the new route reaches 1.000, while legacy routes rise to 2.012. Only the Antimony column changes, including downstream off-diagonal use. Legacy yield/proxy review remains necessary.",
        "B": "Zinc-refining copper co-product rises from 0.013539 to 1.013543. Its other 64 indicators are unchanged. Copper extraction also increases where this co-product enters other producers' supply chains.",
        "C": "Zinc-refining silver co-product rises from 0.000175 to 1.000186. Its other 64 indicators are unchanged. Silver-column changes propagate to other supply chains.",
        "D": "Lithium electrolysis reaches 1.094125 and foil reaches 1.135702. Other indicator columns are unchanged. The retained Spodumene mineral indicator is not additional elemental lithium and must not be summed with Lithium as an independent metal quantity.",
        "E": "Arsenic rises to 1.545436, but Zinc remains 1.552068 in the 7N As row. This repairs missing As attribution only; host-metal proxy attribution remains unresolved. Hold as a complete allocation repair pending review of the zinc-based proxy.",
        "F": "All six metallurgical silicon outputs reach 1.001663–1.003107. Other columns are unchanged. Previously missing Silicon attribution propagates substantially: ZA iridium's Silicon score rises from 146.292055 to 161.865336.",
        "G": "The carbonate-branch transfer restores oxide-contained REE attribution and removes inherited co-mined REE baskets. Dy rises to 1.190680 while its Nd falls from 1.589950 to 0.000609. Non-REE columns, including Sodium and Iron, are unchanged by G.",
        "combined": "All seven resource-only sensitivities combined. The technosphere and physical supplier demand are unchanged. Effects add exactly; 20 indicator columns change. This assessment does not implement production rules or qualify proxy inventories.",
    }
    data = {
        "indicators": indicators,
        "producers": [{k: r[k] for k in ("metal", "name", "product", "location")} for r in before],
        "before": [[float(r[k]) for k in indicators] for r in before],
        "after": {fix: [[float(r[k]) for k in indicators] for r in rows] for fix, rows in stages.items()},
        "conclusions": conclusions,
    }
    payload = json.dumps(data, separators=(",", ":")).replace("<", "\\u003c")
    page = """<!doctype html><html lang="en"><meta charset="utf-8"><title>Whole-row RELICS fix assessment</title>
<style>body{font:15px/1.5 system-ui,sans-serif;color:#172033;max-width:1250px;margin:30px auto;padding:0 20px}h1{font-size:28px}select,input{font:inherit;padding:9px;border:1px solid #cbd5e1;border-radius:5px;margin:5px 8px 5px 0}#producer{max-width:100%;width:100%}.note{background:#eff6ff;padding:15px;border-left:4px solid #2563eb}.meta{color:#475569}table{border-collapse:collapse;width:100%;font-size:14px}th,td{padding:8px;border-bottom:1px solid #e5e7eb;text-align:right}th:first-child,td:first-child{text-align:left}th{background:#f1f5f9;position:sticky;top:0}td{font-variant-numeric:tabular-nums}.own{font-weight:700;background:#f0fdf4}.changed{font-weight:600}label{display:inline-block}#count{color:#475569}</style>
<h1>Whole-row RELICS assessment of fixes A–G</h1>
<p class="meta">284 production datasets × 65 indicators · ecoinvent 3.12 cut-off · IMAGE SSP2-M 2020 · kg extracted per kg reference product</p>
<p>Each fix is assessed independently and in combination, using the saved baseline inventory. Physical supplier demand is fixed; the changes concern elementary resource attribution. All 65 scores remain available, including off-diagonal entries. Dataset counts include country proxies.</p>
<label>Fix <select id="fix"><option>A</option><option>B</option><option>C</option><option>D</option><option>E</option><option>F</option><option>G</option><option selected>combined</option></select></label>
<input id="search" placeholder="Filter datasets by metal, name or location">
<select id="producer"></select>
<p id="conclusion" class="note"></p><p id="count"></p>
<label><input type="checkbox" id="changed">Only indicators changing by more than 10⁻⁹ kg/kg</label>
<table><thead><tr><th>Indicator</th><th>Before</th><th>After</th><th>Change</th></tr></thead><tbody id="scores"></tbody></table>
<p class="meta">The dataset's own-element row is highlighted. Remaining rows are ordered by absolute change. Unchanged cross-element extraction can still reflect reagents, infrastructure, residual allocation or proxies; this assessment alone does not validate it. Mineral and elemental indicators are not necessarily additive.</p>
<script>const data=DATA_PAYLOAD;const fix=document.querySelector('#fix'),search=document.querySelector('#search'),producer=document.querySelector('#producer'),changed=document.querySelector('#changed');
function fmt(x){return x===0?'0':Math.abs(x)<.0001?x.toExponential(6):x.toLocaleString('en-US',{maximumSignificantDigits:9});}
function populate(){const previous=producer.value;producer.replaceChildren();data.producers.forEach((p,i)=>{const label=p.metal+' · '+p.name+' | '+p.product+' | '+p.location;if(label.toLowerCase().includes(search.value.toLowerCase())){const option=document.createElement('option');option.value=i;option.textContent=label;producer.append(option);}});if([...producer.options].some(o=>o.value===previous))producer.value=previous;render();}
function render(){const tbody=document.querySelector('#scores');tbody.replaceChildren();document.querySelector('#conclusion').textContent=data.conclusions[fix.value];if(producer.value==='')return;const i=Number(producer.value),p=data.producers[i],a=data.after[fix.value][i],b=data.before[i];const rows=data.indicators.map((name,k)=>({name,b:b[k],a:a[k],d:a[k]-b[k],own:name===p.metal})).sort((x,y)=>Number(y.own)-Number(x.own)||Math.abs(y.d)-Math.abs(x.d)||x.name.localeCompare(y.name));for(const r of rows){if(changed.checked&&Math.abs(r.d)<=1e-9)continue;const tr=document.createElement('tr');if(r.own)tr.className='own';for(const [j,value]of[r.name+(r.own?' (own element)':''),fmt(r.b),fmt(r.a),fmt(r.d)].entries()){const td=document.createElement('td');td.textContent=value;if(j===3&&Math.abs(r.d)>1e-9)td.className='changed';tr.append(td);}tbody.append(tr);}document.querySelector('#count').textContent=rows.filter(r=>Math.abs(r.d)>1e-9).length+' of 65 indicators changed; values in kg/kg.';}
search.addEventListener('input',populate);producer.addEventListener('change',render);fix.addEventListener('change',render);changed.addEventListener('change',render);populate();</script></html>"""
    (root / "report.html").write_text(page.replace("DATA_PAYLOAD", payload))
    with zipfile.ZipFile(root / "reproduction_scripts.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in (Path(__file__), Path(__file__).with_name("assess_relics_resource_fixes.py")):
            archive.write(path, "dev/" + path.name)
    summaries = "\n\n".join(f"{fix}: {text}" for fix, text in conclusions.items())
    readme = f"""Whole-row assessment of proposed resource corrections
=======================================================

Each proposal A–G was applied independently to an in-memory copy of the saved
biosphere matrix. All seven were also combined. No premise production code,
inventory workbook, saved Brightway database or characterization factor was
modified. This is an exact fixed-technosphere sensitivity assessment of the
proposals, not a rebuild with implemented premise rules.

The functional unit is one kg reference product for each of the same 284
production datasets, including country proxies. All 65 RELICS indicators are
recalculated for each case. Positive and negative off-diagonal changes are
reported, not only improvements in the producer's own-element score.

Findings
--------

{summaries}

With all proposals combined, 274/284 own-element results are within +/-10%
(baseline 262), and 270 are within +/-5% (baseline 261). These are descriptive,
unweighted dataset counts; they include regional copies and do not independently
validate physical extraction or inventory quality.

For dysprosium, G changes Nd 1.589950 -> 0.000609 and Pr 0.437149 -> 0.000201;
Dy 0.252891 -> 1.190680. Sodium stays 67.584313 and Iron stays 7.783409.
For arsenic, E changes As ~2.53e-7 -> 1.545436 while Zn stays 1.552068.
For lithium electrolysis, D changes Li ~6.75e-11 -> 1.094125 while Spodumene
stays 31.990875. Spodumene is a mineral indicator, not an additional elemental-Li
quantity to sum with the Lithium indicator.

Verification
------------

Every baseline row was reproduced against the saved audit; maximum absolute
score difference 1.82e-12 kg/kg. For all 19 directly assessed producer rows,
an independent normal Brightway LCIA on a patched biosphere matrix verifies
the calculated full 65-indicator vector; maximum vector difference 2.85e-14.
Combined effects equal the sum of independent effects. The saved database
fingerprint and the original matrices remain unchanged. Changed-pair reporting
uses an absolute 1e-9 kg/kg threshold. See metadata.json and numerical_checks.csv.

Lutetium is included in the complete carbonate-branch resource transfer but has
no indicator in the 65-method RELICS set. Its direct proposed changes are listed
in direct_resource_changes.csv; this score comparison cannot validate its
characterization. The corresponding metadata field records this coverage gap.

Files
-----

* report.html: offline interactive comparison; select any fix and dataset and
  inspect every before/after indicator, with optional changed-indicator filter.
* whole_row_assessment.xlsx: baseline, each individual fix, combined results,
  own-element comparisons and changed-pair tables.
* before_all_indicators.csv and A_all_indicators.csv through G_all_indicators.csv,
  plus combined_all_indicators.csv: complete 284-by-65 matrices.
* all_changed_pairs.csv: every material score change across all producers,
  including off-diagonal effects of each individual fix and the combination.
* focal_rows_all_indicators.csv: all 65 before/after indicators for producers
  directly targeted by the corresponding fix; unchanged indicators retained.
* focal_own_element.csv and focal_offdiagonal_changes.csv: compact focal tables.
* direct_resource_changes.csv: proposed direct elementary-resource adjustments.
* fix_summary.csv: affected dataset/indicator counts and score-band counts.
* reproduction_scripts.zip: exact calculation and packaging scripts under dev/.

Reproduction
------------

Use the premise environment and local Brightway project recorded in metadata.
Extract the archived scripts at the repository root, then run::

    python dev/assess_relics_resource_fixes.py results/metals-primary-relics-20261020-full results/NEW_ASSESSMENT
    python dev/report_relics_fix_assessment.py results/NEW_ASSESSMENT
"""
    (root / "README.rst").write_text(readme)
    print(root / "report.html")


if __name__ == "__main__":
    main()
