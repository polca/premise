"""Package freshly calculated refinery RELICS results for review."""

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill


def read_csv(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--previous", type=Path)
    args = parser.parse_args()
    root = args.directory
    metadata = json.loads((root / "metadata.json").read_text())
    current = [r for r in read_csv(root / "scores.csv") if r["stage"] == "premise"]
    all_indicators = [
        r for r in read_csv(root / "all_indicators.csv") if r["stage"] == "premise"
    ]
    fields = (
        "metal",
        "name",
        "product",
        "location",
        "score",
        "deviation_percent",
        "direct_resource",
        "upstream_resource",
        "band",
        "unit",
        "database",
        "code",
    )
    with (root / "refined_producers.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(current)

    identity_fields = ("name", "product", "location")

    def identity(row):
        return tuple(row[k] for k in identity_fields)

    indicators = sorted({r["indicator"] for r in all_indicators})
    wide = {identity(r): dict(zip(identity_fields, identity(r))) for r in current}
    for row in all_indicators:
        wide[identity(row)][row["indicator"]] = float(row["score"])
    assert len(all_indicators) == len(current) * len(indicators)
    wide_fields = [*identity_fields, *indicators]
    with (root / "refined_producers_all_indicators.csv").open(
        "w", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=wide_fields)
        writer.writeheader()
        writer.writerows(wide[identity(r)] for r in current)

    previous_comparison = []
    if args.previous:
        previous = {
            identity(r): float(r["score"])
            for r in read_csv(args.previous / "scores.csv")
            if r["stage"] == "premise"
        }
        differences = [abs(float(r["score"]) - previous[identity(r)]) for r in current if identity(r) in previous]
        metadata["comparison_with_previous_audit"] = {
            "directory": str(args.previous),
            "matched_producers": len(differences),
            "max_absolute_score_difference": max(differences),
            "changed_by_more_than_1e_minus_8": sum(d > 1e-8 for d in differences),
            "new_producers": len(set(wide) - set(previous)),
            "removed_producers": len(set(previous) - set(wide)),
        }
        for row in current:
            old_score = previous.get(identity(row))
            previous_comparison.append({
                **{k: row[k] for k in ("metal", *identity_fields)},
                "previous_score": old_score,
                "current_score": float(row["score"]),
                "difference": float(row["score"]) - old_score if old_score is not None else None,
            })
        with (root / "comparison_with_previous.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(previous_comparison[0]))
            writer.writeheader()
            writer.writerows(previous_comparison)
    metadata["calculation_completed_utc"] = datetime.now(timezone.utc).isoformat()
    metadata["indicators_per_producer"] = len(indicators)
    metadata["analysis_scripts_sha256"] = {
        str(path.relative_to(Path(__file__).resolve().parents[1])): hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
        for path in [
            Path(__file__).resolve().parent / name
            for name in (
                "audit_refined_metals_relics.py",
                "diagnose_refined_metals_relics.py",
                "report_refined_metals_relics.py",
                "package_refined_metals_relics.py",
            )
        ]
    }
    (root / "metadata.json").write_text(json.dumps(metadata, indent=2))

    scope = [
        ("Source", metadata["source"]),
        ("Calculated database", metadata["database"]),
        ("Brightway project", metadata["project"]),
        (
            "Functional unit",
            "1 kg reference product from each individual primary producer",
        ),
        (
            "Indicators",
            "kg of extracted element per kg reference product, full supply chain",
        ),
        ("Target score", "Own-element RELICS indicator; one is a screening benchmark"),
        ("Applied update", ", ".join(metadata["updates"])),
        ("Full update limitation", metadata["full_metals_update_limitation"]),
        (
            "Exclusions",
            "Markets, secondary outputs, concentrates, compounds, alloys, anodes, unrefined gold",
        ),
        (
            "Qualification",
            "Pig/sponge iron are not assumed pure Fe; ordinary upstream market mixes remain",
        ),
        ("Completed UTC", metadata["calculation_completed_utc"]),
    ]
    workbook = Workbook()
    workbook.remove(workbook.active)
    numeric_fields = {
        "score",
        "deviation_percent",
        "direct_resource",
        "upstream_resource",
        "minimum",
        "median",
        "maximum",
        "producers",
        "within_5_percent",
        "within_10_percent",
    }
    tables = [
        ("Producer scores", list(fields), current),
        ("All RELICS indicators", wide_fields, [wide[identity(r)] for r in current]),
        ("Element summaries", None, read_csv(root / "summary.csv")),
        ("Scope", ["Item", "Value"], [dict(zip(("Item", "Value"), r)) for r in scope]),
    ]
    if previous_comparison:
        tables.append(("Previous audit comparison", None, previous_comparison))
    for title, columns, rows in tables:
        columns = columns or list(rows[0])
        sheet = workbook.create_sheet(title)
        sheet.append(columns)
        for row in rows:
            sheet.append(
                [
                    (
                        float(row[k])
                        if (k in numeric_fields or k in indicators)
                        else row[k]
                    )
                    for k in columns
                ]
            )
        sheet.freeze_panes = "A2"
        sheet.auto_filter.ref = sheet.dimensions
        for cell in sheet[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="1D4ED8")
        for col in sheet.columns:
            label = col[0].value
            sheet.column_dimensions[col[0].column_letter].width = min(
                65, max(14, max(len(str(c.value or "")) for c in col) + 2)
            )
            if label in numeric_fields or label in indicators:
                for cell in col[1:]:
                    cell.number_format = "0.000000E+00"
    workbook.save(root / "refined_metals_relics.xlsx")

    full_update = metadata["updates"] == ["metals"]
    scope_text = (
        "The complete metals update was applied, including material overlays, "
        "metal-market remapping and resource correction. Other sector updates were excluded."
        if full_update else
        "Only Metals.post_allocation_correction was applied. Material overlays and "
        "metal-market remapping were excluded. " + str(metadata.get("full_metals_update_limitation") or "")
    )
    reproduction_options = "" if full_update else "--correction-only "
    readme = f"""Refined-metal RELICS recalculation
=================================

Completed: {metadata['calculation_completed_utc']}.

Rebuilt from ecoinvent 3.12 cut-off using the current checkout,
encrypted IMAGE SSP2-M {metadata['scenario']['year']} input, and a newly written isolated database:
``{metadata['database']}``.

There are {len(current)} individual primary producers across {metadata['elements']}
elements. {metadata['within_5_percent']} producers are within +/-5% of one kg/kg;
{metadata['within_10_percent']} are within +/-10%. All {len(indicators)} matched
RELICS indicators were recalculated for every producer, as well as original
ecoinvent counterparts where present.

Scope
-----

{scope_text}

Functional units are one kg from individual primary production datasets,
including primary co-products. Markets, secondary outputs, concentrates,
compounds, alloys, anodes and unrefined gold are excluded as functional units.
Pig iron and sponge iron remain without assuming pure Fe content. Ordinary
upstream market mixes remain in the supply chains.

The own-element score is kg target element extracted per kg reference product,
including the full upstream supply chain. One is a screening benchmark for
resource attribution, not an independent proof of physical extraction or
recovery efficiency. Attribution/characterization gaps remain for several
routes; a low score does not demonstrate negligible physical extraction.

Files
-----

* ``refined_metals_relics.xlsx``: one row per producer, all indicators, element
  summaries and explicit scope, in separate sheets.
* ``report.html``: standalone searchable report and plot.
* ``refined_producers.csv``: {len(current)} own-element results, direct/upstream split.
* ``refined_producers_all_indicators.csv``: one row per producer, one column
  per indicator (all values in kg extracted per kg reference product).
* ``scores.csv`` and ``all_indicators.csv``: both source and corrected results.
* ``summary.csv``: minimum, median and maximum per element.
* ``comparison_with_previous.csv``: own-element score changes from the previous audit, when supplied.
* ``numerical_verification.csv``: independent LCIA and solve checks for every
  producer. ``coverage.csv`` records matched RELICS factors.
* ``metadata.json``: database fingerprints, code/configuration hashes, numerical
  checks and comparison against the previous audit.

Reproduction
------------

Use the premise environment with ``PREMISE_KEY`` set. A unique new database
name is required; the calculation script refuses to overwrite a database::

    python dev/audit_refined_metals_relics.py --database UNIQUE_NEW_NAME \\
      {reproduction_options}--output results/NEW_DIRECTORY
    python dev/diagnose_refined_metals_relics.py results/NEW_DIRECTORY
    python dev/package_refined_metals_relics.py results/NEW_DIRECTORY
    python dev/report_refined_metals_relics.py results/NEW_DIRECTORY
"""
    (root / "README.rst").write_text(readme)
    print(
        json.dumps(
            {
                k: metadata.get(k)
                for k in (
                    "selected_producers",
                    "elements",
                    "indicators_per_producer",
                    "within_5_percent",
                    "within_10_percent",
                    "comparison_with_previous_audit",
                )
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
