"""Render the aggregate refined-metal RELICS audit as a standalone report."""

import argparse
import base64
import csv
import html
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    metadata = json.loads((root / "metadata.json").read_text())
    with (root / "scores.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    for row in rows:
        for field in (
            "score",
            "direct_resource",
            "upstream_resource",
            "deviation_percent",
        ):
            row[field] = float(row[field])
    current = [r for r in rows if r["stage"] == "premise"]
    source = {
        (r["name"], r["product"], r["location"]): r
        for r in rows
        if r["stage"] == "source"
    }
    metals = sorted({r["metal"] for r in current})

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    fig, ax = plt.subplots(figsize=(10, max(8, len(metals) * 0.34)))
    ax.axvspan(0.9, 1.1, color="#dbeafe", zorder=0)
    ax.axvspan(0.95, 1.05, color="#bfdbfe", zorder=0)
    ax.axvline(1, color="#1e3a8a", linewidth=1, zorder=1)
    for y, metal in enumerate(metals):
        group = [r for r in current if r["metal"] == metal]
        jitter = np.linspace(-0.2, 0.2, len(group)) if len(group) > 1 else [0]
        for offset, row in zip(jitter, group):
            baseline = source.get((row["name"], row["product"], row["location"]))
            if baseline is not None:
                ax.scatter(
                    max(baseline["score"], 1e-15),
                    y + offset,
                    color="#a1a1aa",
                    s=17,
                    marker="x",
                    zorder=2,
                )
            ax.scatter(
                max(row["score"], 1e-15),
                y + offset,
                color="#b45309" if abs(row["score"] - 1) > 0.1 else "#1d4ed8",
                s=24,
                zorder=3,
            )
    ax.set_xscale("log")
    ax.set_yticks(range(len(metals)), metals)
    ax.invert_yaxis()
    ax.set_xlabel("kg target element extracted per kg refined product (log scale)")
    ax.set_title(
        "Individual primary producers: RELICS extraction\nBlue: premise; orange: >10% from one; grey ×: original ecoinvent",
        loc="left",
        fontsize=12,
    )
    ax.grid(axis="x", alpha=0.2)
    ax.spines[["top", "right"]].set_visible(False)
    fig.tight_layout()
    fig.savefig(root / "refined_metals_relics.png", dpi=180)
    fig.savefig(root / "refined_metals_relics.pdf")
    plt.close(fig)

    summary = []
    for metal in metals:
        group = [r for r in current if r["metal"] == metal]
        values = [r["score"] for r in group]
        summary.append(
            f"<tr><td>{html.escape(metal)}</td><td>{len(group)}</td><td>{min(values):.5g}</td><td>{np.median(values):.5g}</td><td>{max(values):.5g}</td><td>{sum(abs(v-1)<=.1 for v in values)}/{len(values)}</td></tr>"
        )
    table_rows = []
    for row in sorted(
        current,
        key=lambda r: (-abs(r["score"] - 1), r["metal"], r["name"], r["location"]),
    ):
        baseline = source.get((row["name"], row["product"], row["location"]))
        cells = [
            row["metal"],
            row["name"],
            row["product"],
            row["location"],
            f'{baseline["score"]:.6g}' if baseline else "Imported inventory",
            f'{row["score"]:.6g}',
            f'{row["deviation_percent"]:+.2f}%',
            f'{row["direct_resource"]:.6g}',
            f'{row["upstream_resource"]:.6g}',
        ]
        table_rows.append(
            f'<tr data-metal="{html.escape(row["metal"])}" data-outlier="{str(abs(row["score"]-1)>.1).lower()}">'
            + "".join(f"<td>{html.escape(str(v))}</td>" for v in cells)
            + "</tr>"
        )
    image = base64.b64encode((root / "refined_metals_relics.png").read_bytes()).decode()
    full_update = metadata["updates"] == ["metals"]
    scope_text = (
        "The complete metals update was applied, including material overlays, "
        "metal-market remapping and resource correction. Other sector updates were excluded."
        if full_update else
        "Only Metals.post_allocation_correction was applied. Material overlays and "
        "metal-market remapping were excluded. " + str(metadata.get("full_metals_update_limitation") or "")
    )
    departures = []
    for metal in metals:
        group = [r for r in current if r["metal"] == metal and abs(r["score"] - 1) > .1]
        if group:
            values = [r["score"] for r in group]
            departures.append(
                f"<li><strong>{html.escape(metal)}:</strong> {len(group)} producers outside ±10%; "
                f"own-element scores {min(values):.6g}–{max(values):.6g} kg/kg.</li>"
            )
    data = json.dumps(metadata, indent=2)
    page = """<!doctype html><html lang="en"><meta charset="utf-8"><title>Refined metal extraction audit</title>
<style>body{font:15px/1.5 system-ui,sans-serif;color:#172033;max-width:1450px;margin:32px auto;padding:0 24px}h1{font-size:30px}h2{margin-top:32px}.cards{display:flex;gap:20px;flex-wrap:wrap}.card{background:#eff6ff;padding:16px 22px;border-radius:9px}.card strong{font-size:26px;display:block}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;padding:8px;border-bottom:1px solid #e5e7eb}th{background:#eff6ff;position:sticky;top:0}td:nth-child(n+5){font-variant-numeric:tabular-nums}.scroll{overflow:auto;max-height:700px}input,select{font:inherit;padding:8px;margin:8px}img{max-width:100%;width:900px}pre{white-space:pre-wrap;font-size:12px}.note{background:#fffbeb;padding:16px;border-left:4px solid #d97706}.muted{color:#475569}</style>
<h1>RELICS extraction per kg of refined primary product</h1>
<p class="muted">Fresh ecoinvent 3.12 cut-off build; IMAGE SSP2-M input, YEAR. Functional unit: 1 kg from each individual production dataset.</p>
<div class="cards"><div class="card"><strong>N</strong>individual producers</div><div class="card"><strong>M</strong>elements</div><div class="card"><strong>FIVE / N</strong>within ±5% of one</div><div class="card"><strong>TEN / N</strong>within ±10% of one</div></div>
<p>Markets, recycling outputs, concentrates, anodes, oxides, salts, alloys, and unrefined gold are excluded as functional units. Primary co-product routes, including gold recovered from copper anode slime, are included. Ordinary upstream markets remain in the supply chains.</p>
<p><strong>Scope:</strong> UPDATE_SCOPE Imported elemental products are included even where their resource-attribution coverage is incomplete. Pig iron and sponge iron are reported as primary metal outputs; their product composition is not assumed to be pure Fe.</p>
<p class="note">This is a consistency check of the resource-attribution convention. Many direct resource exchanges are set to one by premise, so agreement is not independent validation of ore grades, physical recoveries, or allocation. Values above one may include recovery losses and upstream extraction for other inputs; values below one require checking attribution and upstream supply mixtures.</p>
<h2>All producers</h2><img alt="Extraction scores by element, original ecoinvent and premise" src="data:image/png;base64,PLOT_DATA">
<h2>Summary by element</h2><table><thead><tr><th>Element</th><th>Producers</th><th>Minimum</th><th>Median</th><th>Maximum</th><th>Within ±10%</th></tr></thead><tbody>SUMMARY</tbody></table>
<h2>Departures in this calculation</h2><ul>DEPARTURES</ul>
<p>See attribution_decisions.csv for mapping coverage, reachable upstream resources and matching feed masses, and outlier_contributions.csv for the principal contributing activities. Scores below one can reflect missing attribution or characterization. Scores above one can include recovery losses and extraction for upstream inputs. These results alone do not establish physical recovery efficiency.</p>
<h2>Producer detail</h2><p>Sorted by distance from one. “Direct” is the target-resource exchange at the producer; “upstream” is the remaining supply-chain contribution. Source comparisons use the same activity, product, and geography in original ecoinvent; imported inventories have no original counterpart.</p>
<input id="search" placeholder="Search process or location"><select id="metal"><option value="">All elements</option>OPTIONS</select><label><input id="outliers" type="checkbox">Only outside ±10%</label><span id="count"></span>
<div class="scroll"><table id="detail"><thead><tr><th>Element</th><th>Activity</th><th>Reference product</th><th>Location</th><th>Original ecoinvent</th><th>Premise</th><th>Deviation</th><th>Direct</th><th>Upstream</th></tr></thead><tbody>DETAILS</tbody></table></div>
<h2>Reproducibility</h2><p>CSV outputs: scores.csv, all_indicators.csv, summary.csv, outlier_contributions.csv, lcia_cross_checks.csv, coverage.csv, and excluded_activities.csv. Plot exports are available as PNG and PDF.</p><pre>METADATA</pre>
<script>const search=document.querySelector('#search'),metal=document.querySelector('#metal'),outliers=document.querySelector('#outliers');function filter(){let n=0;for(const r of document.querySelectorAll('#detail tbody tr')){const show=r.textContent.toLowerCase().includes(search.value.toLowerCase())&&(!metal.value||r.dataset.metal===metal.value)&&(!outliers.checked||r.dataset.outlier==='true');r.hidden=!show;if(show)n++}document.querySelector('#count').textContent=n+' producers'}for(const el of [search,metal,outliers])el.addEventListener('input',filter);filter();</script></html>"""
    replacements = {
        "YEAR": str(metadata["scenario"]["year"]),
        "UPDATE_SCOPE": html.escape(scope_text),
        "DEPARTURES": "".join(departures),
        "FIVE": str(metadata["within_5_percent"]),
        "TEN": str(metadata["within_10_percent"]),
        "PLOT_DATA": image,
        "SUMMARY": "".join(summary),
        "OPTIONS": "".join(f"<option>{html.escape(m)}</option>" for m in metals),
        "DETAILS": "".join(table_rows),
        "METADATA": html.escape(data),
    }
    for key, value in replacements.items():
        page = page.replace(key, value)
    # Replace count placeholders only in the cards, avoiding single-letter
    # substitution in prose, JavaScript, and embedded image data.
    page = (
        page.replace("<strong>N</strong>", f"<strong>{len(current)}</strong>")
        .replace(" / N</strong>", f" / {len(current)}</strong>")
        .replace("<strong>M</strong>", f"<strong>{len(metals)}</strong>")
    )
    (root / "report.html").write_text(page)
    print(root / "report.html")


if __name__ == "__main__":
    main()
