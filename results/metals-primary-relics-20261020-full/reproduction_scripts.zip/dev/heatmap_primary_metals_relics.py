"""Draw all primary-producer RELICS scores, annotated to one decimal place."""

import argparse
import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import Normalize
from matplotlib.patches import Patch, Rectangle


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    source = root / "refined_producers_all_indicators.csv"
    rows = list(csv.DictReader(source.open()))
    producers = list(csv.DictReader((root / "refined_producers.csv").open()))
    identity = lambda r: (r["name"], r["product"], r["location"])
    targets = {identity(r): r["metal"] for r in producers}
    indicators = sorted(set(rows[0]) - {"name", "product", "location"})
    rows.sort(key=lambda r: (targets[identity(r)], *identity(r)))
    values = np.array([[float(r[c]) for c in indicators] for r in rows])
    assert values.shape == (len(producers), len(indicators))
    assert np.isfinite(values).all() and (values >= 0).all()
    labels = [
        f"{targets[identity(r)]} · {r['name']} | {r['product']} | {r['location']}"
        for r in rows
    ]

    dpi, cell_width, cell_height = 150, 57, 27
    left, right, top, bottom = 1510, 80, 450, 70
    width = left + len(indicators) * cell_width + right
    height = top + len(rows) * cell_height + bottom
    fig = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi, facecolor="white")
    ax = fig.add_axes([
        left / width, bottom / height,
        len(indicators) * cell_width / width, len(rows) * cell_height / height,
    ])
    cmap = plt.get_cmap("RdYlGn")
    colors = cmap(np.clip(values, 0, 1))
    purple = matplotlib.colors.to_rgba("#65388c")
    colors[values > 1.1] = purple
    own_columns = np.array([indicators.index(targets[identity(row)]) for row in rows])
    own_mask = np.zeros(values.shape, dtype=bool)
    own_mask[np.arange(len(rows)), own_columns] = True
    assert own_mask.sum() == len(rows) and (own_mask.sum(axis=1) == 1).all()
    colors[~own_mask] = matplotlib.colors.to_rgba("white")
    ax.imshow(colors, aspect="auto", interpolation="nearest", rasterized=True)
    ax.set_xticks(range(len(indicators)), indicators, rotation=90, fontsize=8)
    ax.xaxis.tick_top()
    ax.tick_params(axis="x", length=0, pad=10)
    ax.set_yticks(range(len(rows)), labels, fontsize=6.8)
    ax.tick_params(axis="y", length=0, pad=10)
    ax.set_xticks(np.arange(-0.5, len(indicators), 1), minor=True)
    ax.set_yticks(np.arange(-0.5, len(rows), 1), minor=True)
    ax.grid(which="minor", color="#d9dee5", alpha=0.65, linewidth=0.35)
    ax.tick_params(which="minor", length=0)

    for y, row in enumerate(rows):
        for x, value in enumerate(values[y]):
            red, green, blue, _ = colors[y, x]
            luminance = .2126 * red + .7152 * green + .0722 * blue
            ax.text(
                x, y, f"{value:.1f}", ha="center", va="center", fontsize=6.1,
                color=("white" if luminance < .53 else "#172033") if own_mask[y, x] else "#747d88",
            )
        own_x = own_columns[y]
        ax.add_patch(Rectangle(
            (own_x - .5, y - .5), 1, 1, fill=False,
            edgecolor="#102132", linewidth=1.4,
        ))
        if y and targets[identity(rows[y - 1])] != targets[identity(row)]:
            ax.axhline(y - .5, color="#94a3b8", linewidth=1)

    fig.text(50 / width, 1 - 45 / height,
             "RELICS extraction by primary metal production dataset", fontsize=23,
             weight="bold", va="top", color="#172033")
    fig.text(50 / width, 1 - 100 / height,
             f"{len(rows)} datasets × {len(indicators)} indicators · kg extracted per kg reference product · "
             "ecoinvent 3.12 cut-off · full metals update · IMAGE SSP2-M 2020",
             fontsize=12, va="top", color="#344054")
    fig.text(50 / width, 1 - 140 / height,
             "Values rounded to one decimal; colors use unrounded scores. "
             "Only matching metal–indicator cells are colored and outlined; all other cells have a white background.",
             fontsize=11, va="top", color="#344054")
    fig.text(50 / width, 1 - 178 / height,
             "Many resource exchanges follow an attribution convention; proximity to one does not independently validate physical extraction.",
             fontsize=10, va="top", color="#475467")
    cax = fig.add_axes([left / width, 1 - 210 / height, 580 / width, 18 / height])
    colorbar = fig.colorbar(matplotlib.cm.ScalarMappable(norm=Normalize(0, 1), cmap=cmap),
                           cax=cax, orientation="horizontal", ticks=[0, .25, .5, .75, 1])
    colorbar.ax.tick_params(labelsize=9, length=2)
    fig.legend(handles=[
        Patch(facecolor=purple, label="Above 1.1 kg (above target range)"),
        Patch(facecolor=cmap(1.0), label="1.0–1.1 kg also shown green"),
        Patch(facecolor="none", edgecolor="#102132", linewidth=1.4, label="Own-element score"),
    ], loc="upper left", bbox_to_anchor=((left + 680) / width, 1 - 180 / height),
       frameon=False, fontsize=10, ncol=3)
    output = root / "relics_heatmap.png"
    fig.savefig(output, dpi=dpi, facecolor="white")
    plt.close(fig)
    (root / "relics_heatmap_metadata.json").write_text(json.dumps({
        "source": str(source), "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "rows": len(rows), "columns": len(indicators), "annotations": values.size,
        "width_pixels": width, "height_pixels": height, "display_decimals": 1,
        "rounding": "nearest one decimal using Python fixed-point formatting",
        "color_scale": "RdYlGn, linear 0–1; 1–1.1 green; >1.1 purple",
        "colored_cells": int(own_mask.sum()), "uncolored_cells": int((~own_mask).sum()),
        "color_selection": "only the RELICS indicator matching each dataset's target metal",
        "colors_use_unrounded_scores": True, "above_1_1": int((values > 1.1).sum()),
        "colored_above_1_1": int(((values > 1.1) & own_mask).sum()),
        "minimum": float(values.min()), "maximum": float(values.max()),
        "row_order": "target element, activity name, reference product, location",
        "column_order": indicators, "script": str(Path(__file__)),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }, indent=2))
    print(f"{output}: {width} × {height} pixels; {values.size} annotated scores")


if __name__ == "__main__":
    main()
