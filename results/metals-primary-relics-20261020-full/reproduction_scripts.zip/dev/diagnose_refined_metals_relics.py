"""Verify refinery audit solves and trace current attribution decisions."""

import argparse
import csv
import json
import pickle
import sqlite3
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def write_csv(path, rows):
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    args = parser.parse_args()
    root = args.directory
    meta = json.loads((root / "metadata.json").read_text())
    import bw2data as bd
    import bw2calc as bc
    import numpy as np
    from premise.metals import (
        Metals,
        exchange_may_carry_target_resource,
        is_pure_target_resource_product,
    )

    bd.projects.set_current(meta["project"])
    rows = list(csv.DictReader((root / "scores.csv").open()))
    current = [r for r in rows if r["stage"] == "premise"]
    activities = [bd.get_node(database=r["database"], code=r["code"]) for r in current]
    lca = bc.LCA(
        {activities[0].id: 1}, ("RELICS", "metals extraction", current[0]["metal"])
    )
    lca.lci(factorize=True)
    numerical = []
    for row, activity in zip(current, activities):
        production = list(activity.production())
        if len(production) != 1 or not np.isclose(production[0]["amount"], 1):
            raise ValueError(f"Non-unit reference production: {activity.key}")
        lca.redo_lci({activity.id: 1})
        residual = float(
            np.max(
                np.abs(lca.technosphere_matrix @ lca.supply_array - lca.demand_array)
            )
        )
        lca.switch_method(("RELICS", "metals extraction", row["metal"]))
        lca.lcia()
        difference = abs(lca.score - float(row["score"]))
        if residual > 1e-7 or not np.isclose(
            lca.score, float(row["score"]), rtol=1e-8, atol=1e-10
        ):
            raise ValueError(
                f"Numerical check failed: {activity.key}, {residual}, {difference}"
            )
        numerical.append(
            {
                "metal": row["metal"],
                "name": row["name"],
                "location": row["location"],
                "residual_max_abs": residual,
                "score_difference": difference,
                "production_amount": production[0]["amount"],
            }
        )
    write_csv(root / "numerical_verification.csv", numerical)

    # Read the written inventory without mutating any Brightway nodes.
    connection = sqlite3.connect(
        "file:" + str(Path(bd.projects.dir) / "lci/databases.db") + "?mode=ro", uri=True
    )
    datasets = {}
    for code, raw in connection.execute(
        'SELECT code,data FROM activitydataset WHERE "database"=?', (meta["database"],)
    ):
        dataset = pickle.loads(raw)
        dataset["exchanges"] = []
        datasets[code] = dataset
    biosphere = {
        code: pickle.loads(raw)
        for code, raw in connection.execute(
            'SELECT code,data FROM activitydataset WHERE "database"=?',
            (meta["biosphere"],),
        )
    }
    for code, raw in connection.execute(
        "SELECT output_code,data FROM exchangedataset WHERE output_database=?",
        (meta["database"],),
    ):
        e = pickle.loads(raw)
        if e["type"] == "biosphere":
            e["categories"] = biosphere[e["input"][1]]["categories"]
        datasets[code]["exchanges"].append(e)
    correction = object.__new__(Metals)
    correction.database = list(datasets.values())
    correction.version = "3.12"
    correction.system_model = "cutoff"
    correction.build_in_ground_resource_exchange_index()
    mapped = correction.get_mining_share_dataset_ids()
    providers = correction.build_exchange_provider_index()
    decisions = []
    for row in current:
        if abs(float(row["score"]) - 1) <= 0.1:
            continue
        dataset = datasets[row["code"]]
        metal = row["metal"]
        feeds = [
            e
            for e in dataset["exchanges"]
            if e.get("type") == "technosphere"
            and e.get("amount", 0) > 0
            and exchange_may_carry_target_resource(e, metal)
        ]
        upstream = correction.target_resource_is_supplied_upstream(
            dataset, metal, providers, {}
        )
        decisions.append(
            {
                "metal": metal,
                "name": row["name"],
                "product": row["product"],
                "location": row["location"],
                "score": row["score"],
                "selected_for_primary_attribution": id(dataset) in mapped,
                "recognized_as_pure_target": is_pure_target_resource_product(
                    row["product"], metal
                ),
                "upstream_target_reachable": upstream,
                "matching_feed_mass_kg": sum(e["amount"] for e in feeds if e.get("unit") == "kilogram"),
                "matching_feeds": json.dumps(
                    [
                        {k: e.get(k) for k in ["name", "product", "location", "amount", "unit"]}
                        for e in feeds
                    ]
                ),
            }
        )
    write_csv(root / "attribution_decisions.csv", decisions)
    meta["numerical_verification"] = {
        "producers": len(numerical),
        "max_absolute_residual": max(r["residual_max_abs"] for r in numerical),
        "max_direct_lcia_difference": max(r["score_difference"] for r in numerical),
        "reference_production_amounts_all_one": True,
    }
    (root / "metadata.json").write_text(json.dumps(meta, indent=2))
    print(meta["numerical_verification"])
    for r in decisions:
        if r["metal"] in {
            "Copper",
            "Lead",
            "Silver",
            "Lithium",
            "Silicon",
            "Arsenic",
            "Gallium",
        }:
            print({k: v for k, v in r.items() if k != "matching_feeds"})


if __name__ == "__main__":
    main()
