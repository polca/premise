"""Audit RELICS extraction per kg of individual primary refined-metal output.

Builds a fresh metals-only scenario, never overwrites a database, and exports
only activity identities, aggregate scores, and contribution summaries.
Run in the premise environment with PREMISE_KEY set for encrypted IAM input.
"""

import argparse
import csv
import gc
import hashlib
import importlib.metadata
import json
import os
import subprocess
import sys
import time
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def write_csv(path, rows):
    if rows:
        with path.open("w", newline="") as stream:
            writer = csv.DictWriter(
                stream, fieldnames=list(rows[0]), lineterminator="\n"
            )
            writer.writeheader()
            writer.writerows(rows)


def identity(activity):
    return activity["name"], activity.get("reference product"), activity.get("location")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project", default="metals-correctness-3.12-cutoff")
    parser.add_argument("--source", default="ecoinvent-3.12-cutoff")
    parser.add_argument("--biosphere", default="ecoinvent-3.12-biosphere")
    parser.add_argument("--database", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--year", type=int, default=2020)
    parser.add_argument("--reuse-build", action="store_true")
    parser.add_argument(
        "--full-metals-update-limitation",
        default="Full metals update not applied; resource-correction-only audit.",
        help="Record the known full-update blocker when using --correction-only",
    )
    parser.add_argument(
        "--correction-only",
        action="store_true",
        help="Apply current resource correction without unrelated material overrides or market remapping",
    )
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()

    import bw2calc as bc
    import bw2data as bd
    import numpy as np
    import pandas as pd
    from premise import NewDatabase
    from premise.metals import (
        METAL_RESOURCE_FLOW_NAMES,
        is_pure_target_resource_product,
        load_mining_shares_mapping,
        matches_filter_query,
        parse_mining_filter,
    )
    from relics.utils import RELICS_MAPPING, load_mappings

    bd.projects.set_current(args.project)
    for name in (args.source, args.biosphere):
        if name not in bd.databases:
            raise ValueError(f"Missing database: {name}")
    metadata_path = args.output / "metadata.json"
    code_hash = hashlib.sha256((ROOT / "premise/metals.py").read_bytes()).hexdigest()
    boundaries_hash = hashlib.sha256((ROOT / "premise/metals_resource_boundaries.py").read_bytes()).hexdigest()
    if args.reuse_build:
        metadata = json.loads(metadata_path.read_text())
        if args.database not in bd.databases or metadata["metals_sha256"] != code_hash or metadata.get("resource_boundaries_sha256") != boundaries_hash:
            raise ValueError(
                "Saved build is absent or does not match current metals code"
            )
    else:
        if args.database in bd.databases:
            raise ValueError(f"Refusing to overwrite {args.database}")
        if not os.environ.get("PREMISE_KEY"):
            raise ValueError(
                "PREMISE_KEY is required; unencrypted IAM fallback is disabled"
            )
        print(
            "BUILD: current checkout, metals-only, encrypted IMAGE SSP2-M", flush=True
        )
        ndb = NewDatabase(
            scenarios=[{"model": "image", "pathway": "SSP2-M", "year": args.year}],
            source_db=args.source,
            source_version="3.12",
            source_type="brightway",
            biosphere_name=args.biosphere,
            system_model="cutoff",
            key=os.environ["PREMISE_KEY"].encode(),
            inventory_backend="compact",
            keep_source_db_uncertainty=False,
            keep_imports_uncertainty=False,
            use_cached_database=True,
            use_cached_inventories=True,
            generate_reports=False,
            quiet=True,
        )
        if args.correction_only:
            from premise.metals import Metals
            from premise.inventory_store import (
                get_scenario_inventory,
                replace_scenario_inventory,
            )
            import premise.new_database as build_module

            def resource_only_update(scenario, version, system_model):
                correction = object.__new__(Metals)
                correction.database = get_scenario_inventory(scenario)
                correction.version = version
                correction.system_model = system_model
                correction._validation_targets = {}
                correction.resource_diagnostics = []
                correction.post_allocation_correction()
                replace_scenario_inventory(scenario, correction.database)
                scenario.setdefault("mapping", {})["metals"] = {
                    "transformed activities": list(
                        correction._validation_targets.values()
                    ),
                    "resource diagnostics": correction.resource_diagnostics,
                    "methodology": {
                        "scope": "current post_allocation_correction only",
                        "corrected datasets": len(correction._validation_targets),
                    },
                }
                print(
                    "RESOURCE CORRECTION CHANGED",
                    len(correction._validation_targets),
                    "datasets",
                    flush=True,
                )
                if len(correction._validation_targets) < 100:
                    raise ValueError(
                        "Resource correction unexpectedly changed too few datasets"
                    )
                return scenario

            original_wrapper = build_module._update_metals
            build_module._update_metals = resource_only_update
            try:
                ndb.update("metals")
            finally:
                build_module._update_metals = original_wrapper
            mapping = ndb.scenarios[0]["mapping"]["metals"]
        else:
            ndb.update("metals")
            mapping = ndb.scenarios[0].get("mapping", {}).get("metals", {})
        for key in ("resource diagnostics", "methodology"):
            (args.output / (key.replace(" ", "_") + ".json")).write_text(
                json.dumps(mapping.get(key, []), indent=2, default=str)
            )
        metadata = {
            "project": args.project,
            "source": args.source,
            "database": args.database,
            "biosphere": args.biosphere,
            "version": "3.12",
            "system_model": "cutoff",
            "scenario": {"model": "image", "pathway": "SSP2-M", "year": args.year},
            "updates": (
                ["metals.post_allocation_correction"]
                if args.correction_only
                else ["metals"]
            ),
            "encrypted_iam": True,
            "full_metals_update_limitation": (
                args.full_metals_update_limitation if args.correction_only else None
            ),
            "metals_sha256": code_hash,
            "resource_boundaries_sha256": boundaries_hash,
            "activities_mapping_sha256": hashlib.sha256(
                (ROOT / "premise/data/metals/activities_mapping.yml").read_bytes()
            ).hexdigest(),
            "git_commit": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            "build_seconds": time.perf_counter() - started,
        }
        ndb.write_db_to_brightway(args.database)
        if args.correction_only:
            gold = [
                a
                for a in bd.Database(args.database)
                if identity(a)
                == (
                    "processing of anode slime from electrorefining of copper, anode",
                    "gold",
                    "GLO",
                )
            ]
            gold_amount = sum(
                float(e["amount"])
                for e in gold[0].biosphere()
                if e.input["name"] == "Gold"
            )
            if len(gold) != 1 or not abs(gold_amount - 1) < 1e-10:
                raise ValueError(
                    f"Resource correction did not survive export: direct gold={gold_amount}"
                )
            metadata["export_gold_resource_check"] = gold_amount
            metadata["corrected_datasets"] = mapping["methodology"][
                "corrected datasets"
            ]
        metadata_path.write_text(json.dumps(metadata, indent=2))
        del ndb
        gc.collect()
    print("BUILD READY", args.database, flush=True)

    # Register and verify the actual RELICS mappings against this biosphere.
    flows = list(bd.Database(args.biosphere))
    methods, coverage = [], []
    for mapping in load_mappings(RELICS_MAPPING):
        factors = {}
        for rule in mapping["environmental flow"]:
            matches = [
                f
                for f in flows
                if f["name"].lower().startswith(rule["name"].lower())
                and tuple(f["categories"]) == tuple(rule["categories"].split("::"))
            ]
            coverage.append(
                {
                    "indicator": mapping["name"],
                    "pattern": rule["name"],
                    "matched_flows": len(matches),
                    "factor": rule["amount"],
                }
            )
            for flow in matches:
                if flow.id in factors and factors[flow.id] != rule["amount"]:
                    raise ValueError("Conflicting RELICS factors")
                factors[flow.id] = rule["amount"]
        key = ("RELICS", "metals extraction", mapping["name"])
        if key not in bd.methods:
            bd.Method(key).register(unit="kilogram")
        if dict(bd.Method(key).load()) != factors:
            bd.Method(key).write(list(factors.items()))
        if factors:
            methods.append(key)
    write_csv(args.output / "coverage.csv", coverage)
    indicators = {m[-1]: i for i, m in enumerate(methods)}

    # Independent activity selection: final elemental products, not concentrates,
    # compounds, alloys, anodes, unrefined gold, markets or recycling outputs.
    mapping = load_mining_shares_mapping("3.12")
    selectors = [
        (
            parse_mining_filter(row["Process"]),
            parse_mining_filter(row["Reference product"]),
        )
        for _, row in mapping.loc[mapping["Work done"] == "Yes"]
        .drop_duplicates(["Process", "Reference product"])
        .iterrows()
    ]
    secondary = __import__("yaml").safe_load(
        (ROOT / "premise/data/metals/secondary_supply_activities.yaml").read_text()
    )
    selected, exclusions = [], []
    for activity in bd.Database(args.database):
        name, product, location = identity(activity)
        if activity.get("unit") != "kilogram" or name.startswith(
            ("market for ", "market group for ")
        ):
            continue
        targets = [
            metal
            for metal in METAL_RESOURCE_FLOW_NAMES
            if metal in indicators
            and (
                is_pure_target_resource_product(product or "", metal)
                or (product == "silicon, metallurgical grade" and metal == "Silicon")
            )
        ]
        if len(targets) != 1 or targets[0] in {
            "Graphite",
            "Spodumene",
            "Sulfur",
            "Phosphorus",
            "Sodium",
        }:
            continue
        low_name = name.lower()
        reason = None
        if "unrefined" in (product or "").lower():
            reason = "unrefined intermediate"
        elif any(
            term in low_name
            for term in (
                "treatment of",
                "recycl",
                "secondary",
                "for reuse",
                "post-consumer",
                "scrap",
            )
        ):
            reason = "secondary or recycling activity"
        elif name.startswith("aluminium alloy production"):
            reason = "recovered copper during alloy production"
        elif any(
            all(
                matches_filter_query(value, rule.get(field))
                for field, value in (
                    ("name", name),
                    ("reference product", product),
                    ("location", location),
                )
                if rule.get(field) is not None
            )
            for rule in secondary.get(product, [])
        ):
            reason = "configured secondary route"
        elif not any(
            matches_filter_query(name, p) and matches_filter_query(product, r)
            for p, r in selectors
        ) and not any(
            term in low_name
            for term in (
                "production",
                "refining",
                "electrorefining",
                "extraction",
                "mine operation",
            )
        ):
            reason = "no primary production evidence"
        if reason:
            exclusions.append(
                {
                    "name": name,
                    "product": product,
                    "location": location,
                    "reason": reason,
                }
            )
        else:
            selected.append((activity, targets[0]))
    selected.sort(key=lambda x: (x[1], *identity(x[0])))
    if not selected:
        raise ValueError("No refined primary producers selected")
    write_csv(
        args.output / "excluded_activities.csv",
        sorted(exclusions, key=lambda x: (x["product"], x["name"], x["location"])),
    )
    print(
        f"SELECTED {len(selected)} individual producers, {len(set(t for _, t in selected))} elements",
        flush=True,
    )

    scores, all_scores, contributions, checks = [], [], [], []
    selected_keys = {identity(a): metal for a, metal in selected}
    for stage, database in (("source", args.source), ("premise", args.database)):
        nodes = list(bd.Database(database))
        lookup = defaultdict(list)
        for activity in nodes:
            lookup[identity(activity)].append(activity)
        activities = [
            (lookup[key][0], metal)
            for key, metal in selected_keys.items()
            if len(lookup[key]) == 1
        ]
        for key in selected_keys:
            if len(lookup[key]) > 1:
                raise ValueError(f"Non-unique activity: {key}")
        print(f"SCORE {stage}: {len(activities)} producers; factorizing", flush=True)
        lca = bc.LCA({activities[0][0].id: 1}, methods[0])
        lca.lci(factorize=True)
        factor_rows = []
        for method in methods:
            lca.switch_method(method)
            factor_rows.append(lca.characterization_matrix.diagonal())
        cf_matrix = np.asarray(factor_rows)
        for position, (activity, metal) in enumerate(activities):
            lca.redo_lci({activity.id: 1})
            inventory = np.asarray(lca.inventory.sum(axis=1)).ravel()
            values = cf_matrix @ inventory
            if not np.isfinite(values).all():
                raise ValueError(f"Non-finite scores: {identity(activity)}")
            own = float(values[indicators[metal]])
            direct = float(
                cf_matrix[indicators[metal]]
                @ lca.biosphere_matrix[:, lca.dicts.activity[activity.id]]
                .toarray()
                .ravel()
            )
            row = {
                "stage": stage,
                "metal": metal,
                "name": activity["name"],
                "product": activity["reference product"],
                "location": activity["location"],
                "database": database,
                "code": activity["code"],
                "functional_unit": 1,
                "unit": "kg extracted/kg refined product",
                "score": own,
                "deviation_percent": (own - 1) * 100,
                "direct_resource": direct,
                "upstream_resource": own - direct,
                "band": (
                    "within 5%"
                    if abs(own - 1) <= 0.05
                    else "within 10%" if abs(own - 1) <= 0.1 else "outside 10%"
                ),
            }
            scores.append(row)
            for method, value in zip(methods, values):
                all_scores.append(
                    {
                        "stage": stage,
                        "name": row["name"],
                        "product": row["product"],
                        "location": row["location"],
                        "indicator": method[-1],
                        "score": float(value),
                    }
                )
            if stage == "premise" and abs(own - 1) > 0.05:
                by_activity = np.asarray(
                    cf_matrix[indicators[metal]] @ lca.inventory
                ).ravel()
                if not np.isclose(by_activity.sum(), own, rtol=1e-8, atol=1e-10):
                    raise ValueError("Contributions fail to reconcile")
                order = np.argsort(np.abs(by_activity))[::-1][:6]
                for col in order:
                    if abs(by_activity[col]) < 1e-12:
                        continue
                    node = bd.get_node(id=lca.dicts.activity.reversed[int(col)])
                    contributions.append(
                        {
                            "metal": metal,
                            "name": row["name"],
                            "product": row["product"],
                            "location": row["location"],
                            "contributor": node["name"],
                            "contributor_product": node.get("reference product"),
                            "contributor_location": node.get("location"),
                            "contribution": float(by_activity[col]),
                        }
                    )
            if position == 0 or metal in {"Copper", "Gold", "Zinc"}:
                lca.switch_method(methods[indicators[metal]])
                lca.lcia()
                if not np.isclose(lca.score, own, rtol=1e-9, atol=1e-10):
                    raise ValueError("Direct LCIA check failed")
                checks.append(
                    {
                        "stage": stage,
                        "name": row["name"],
                        "location": row["location"],
                        "metal": metal,
                        "direct_lcia": float(lca.score),
                        "vectorized": own,
                    }
                )
            if position % 25 == 0:
                print(f"SCORE {stage}: {position + 1}/{len(activities)}", flush=True)
        del lca, nodes, lookup
        gc.collect()
    write_csv(args.output / "scores.csv", scores)
    write_csv(args.output / "all_indicators.csv", all_scores)
    write_csv(args.output / "outlier_contributions.csv", contributions)
    write_csv(args.output / "lcia_cross_checks.csv", checks)
    summaries = []
    current = [r for r in scores if r["stage"] == "premise"]
    for metal in sorted({r["metal"] for r in current}):
        rows = [r for r in current if r["metal"] == metal]
        values = [r["score"] for r in rows]
        summaries.append(
            {
                "metal": metal,
                "producers": len(rows),
                "minimum": min(values),
                "median": float(np.median(values)),
                "maximum": max(values),
                "within_5_percent": sum(abs(v - 1) <= 0.05 for v in values),
                "within_10_percent": sum(abs(v - 1) <= 0.1 for v in values),
            }
        )
    write_csv(args.output / "summary.csv", summaries)
    metadata.update(
        {
            "relics_version": importlib.metadata.version("relics"),
            "relics_mapping_sha256": hashlib.sha256(
                Path(RELICS_MAPPING).read_bytes()
            ).hexdigest(),
            "database_fingerprints": {
                name: hashlib.sha256(
                    Path(bd.Database(name).filepath_processed()).read_bytes()
                ).hexdigest()
                for name in [args.source, args.database]
            },
            "selected_producers": len(current),
            "elements": len(summaries),
            "within_5_percent": sum(abs(r["score"] - 1) <= 0.05 for r in current),
            "within_10_percent": sum(abs(r["score"] - 1) <= 0.1 for r in current),
            "seconds": time.perf_counter() - started,
            "selection": "individual kilogram elemental primary producers; markets, concentrates, compounds, alloys, unrefined and secondary outputs excluded",
            "source_comparison": "matching original ecoinvent identities; imported foreground producers may have no source counterpart",
            "benchmark": "1 kg extracted/kg refined product; screening convention, not proof of physical recovery or purity",
        }
    )
    metadata_path.write_text(json.dumps(metadata, indent=2))
    frame = pd.DataFrame(summaries)
    print(frame.to_string(index=False), flush=True)
    print(
        json.dumps(
            {
                k: metadata[k]
                for k in [
                    "selected_producers",
                    "elements",
                    "within_5_percent",
                    "within_10_percent",
                    "seconds",
                ]
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
