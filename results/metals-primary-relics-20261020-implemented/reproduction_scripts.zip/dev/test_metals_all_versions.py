"""Run the complete metals update across supported releases without DB exports.

Raw build logs stay in /private/tmp; only aggregate validation enters results/.
Each version/system model runs in its own process to isolate Brightway state.
"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "results/metals-all-versions-20261019"
PRIVATE = Path("/private/tmp/metals-all-versions-20261019")
EXCLUDED = {
    "electric motor production, asynchronous, traction": "EV",
    "polyethylene terephthalate adhesive film production, for fuel cells": "PEMFC",
    "motor drive assembly production, electrolysis, AEC": "AEL",
    "motor drive assembly production, electrolysis, SOEC": "HTEL - Yttrium",
    "glass seal production, SOEC, barium alumino-borosilicate": "HTEL - Yttrium",
    "gallium arsenide substrate preparation, for photovoltaic cell production": "c-Si",
}


def snapshot(ndb, scenario):
    metadata, inputs = [], {}
    for dataset in ndb.get_inventory_store(scenario).iter_materialized():
        metadata.append(
            {
                k: dataset.get(k)
                for k in ("name", "reference product", "unit", "location")
            }
        )
        if dataset["name"] not in EXCLUDED:
            continue
        amounts = defaultdict(float)
        for exchange in dataset.get("exchanges", []):
            if exchange["type"] == "technosphere":
                amounts[(exchange["product"], exchange["unit"])] += exchange["amount"]
        identity = tuple(
            dataset.get(k) for k in ("name", "reference product", "location")
        )
        assert identity not in inputs
        inputs[identity] = dict(amounts)
    return metadata, inputs


def worker(case):
    sys.path.insert(0, str(ROOT))
    import bw2data as bd
    from premise import NewDatabase
    from premise.activity_maps import InventorySet

    started = time.perf_counter()
    result = dict(case, status="running", scenarios=[])
    stage = "initialization"
    try:
        if not os.environ.get("PREMISE_KEY"):
            skill = Path("/Users/romain/.codex/skills/premise/SKILL.md").read_text()
            os.environ["PREMISE_KEY"] = re.search(
                r"```text\n([^\n]+)\n```", skill
            ).group(1)
        bd.projects.set_current(case["project"])
        ndb = NewDatabase(
            scenarios=[
                {"model": "image", "pathway": "SSP2-M", "year": year}
                for year in (2020, 2050)
            ],
            source_db=case["source"],
            source_version=case["version"],
            source_type="brightway",
            biosphere_name=case["biosphere"],
            system_model=case["premise_system_model"],
            key=os.environ["PREMISE_KEY"].encode(),
            inventory_backend="compact",
            keep_source_db_uncertainty=False,
            keep_imports_uncertainty=False,
            use_cached_database=True,
            use_cached_inventories=True,
            generate_reports=False,
            quiet=True,
        )
        stage = "mapping checks"
        metadata, before = snapshot(ndb, 0)
        mapping = InventorySet(
            metadata, case["version"]
        ).generate_metals_activities_map()
        for name, technology in EXCLUDED.items():
            assert all(d["name"] != name for d in mapping[technology]), (
                name,
                technology,
            )
        for technology in ("EV", "PEMFC", "AEL", "HTEL - Yttrium", "c-Si"):
            assert mapping[technology], f"Empty intended mapping: {technology}"
        result["mapping_counts"] = {k: len(v) for k, v in mapping.items()}
        result["preserved_component_datasets"] = len(before)
        stage = "metals update"
        ndb.update(["metals"])
        stage = "result checks"
        for index, scenario in enumerate(ndb.scenarios):
            metadata, after = snapshot(ndb, index)
            assert before.keys() == after.keys()
            checked_inputs = 0
            for identity, amounts in before.items():
                assert amounts.keys() == after[identity].keys(), identity
                for key, amount in amounts.items():
                    assert math.isclose(
                        amount, after[identity][key], rel_tol=1e-9, abs_tol=1e-12
                    ), (identity, key, amount, after[identity][key])
                    checked_inputs += 1
            issues = [
                issue
                for phase in scenario.get("_validation_phase_results", [])
                for rule in phase["rule_results"]
                for issue in rule.get("issues", [])
                if not issue.get("suppressed", False)
            ]
            assert not any(i["severity"] == "error" for i in issues), [
                i for i in issues if i["severity"] == "error"
            ]
            metrics = scenario["mapping"]["metals"]["material update metrics"]
            assert metrics["compiled pairs"] == metrics["executed pairs"] > 0
            result["scenarios"].append(
                {
                    "model": scenario["model"],
                    "pathway": scenario["pathway"],
                    "year": scenario["year"],
                    "datasets": len(metadata),
                    "material_update_metrics": metrics,
                    "validation_issue_counts": dict(
                        Counter(i["severity"] for i in issues)
                    ),
                    "warning_counts_by_rule": dict(
                        Counter(
                            i["rule_id"] for i in issues if i["severity"] == "warning"
                        )
                    ),
                    "component_input_groups_unchanged": checked_inputs,
                }
            )
        result["status"] = "passed"
    except Exception as error:
        result.update(
            status="failed",
            stage=stage,
            error_type=type(error).__name__,
            error=str(error),
        )
        traceback.print_exc()
    result["seconds"] = time.perf_counter() - started
    result["completed_utc"] = datetime.now(timezone.utc).isoformat()
    (OUTPUT / (case["id"] + ".json")).write_text(
        json.dumps(result, indent=2, default=str)
    )
    print(
        "CASE RESULT",
        json.dumps(
            {k: result.get(k) for k in ("id", "status", "stage", "error", "seconds")}
        ),
        flush=True,
    )
    return result


def discover():
    import bw2data as bd
    import yaml

    versions = yaml.safe_load(
        (ROOT / "premise/iam_variables_mapping/constants.yaml").read_text()
    )["SUPPORTED_EI_VERSIONS"]
    # Legacy releases before 3.8 are not supported by premise's consequential API.
    consequential = {"3.8", "3.9", "3.9.1", "3.10", "3.10.1", "3.11", "3.12"}
    catalogue = []
    current = bd.projects.current
    for project in bd.projects:
        bd.projects.set_current(project.name)
        catalogue.append((project.name, dict(bd.databases)))
    bd.projects.set_current(current)
    cases = []
    for version in versions:
        models = ["cutoff"] + (["consequential"] if version in consequential else [])
        if version == "3.12":
            models.append("EN15804")
        for model in models:
            name = f"ecoinvent-{version}-{model}"
            candidates = [
                (p, d)
                for p, d in catalogue
                if name in d and d[name].get("number", 0) > 10000
            ]
            candidates.sort(
                key=lambda pair: (
                    pair[0] != name,
                    not pair[0].startswith("brightpath-reference-"),
                    pair[0],
                )
            )
            row = {
                "id": f"{version}-{model}",
                "version": version,
                "system_model": model,
                "premise_system_model": "cutoff" if model == "EN15804" else model,
                "source": name,
            }
            if candidates:
                project, databases = candidates[0]
                biospheres = [n for n in databases if "biosphere" in n.lower()]
                biospheres.sort(
                    key=lambda n: (
                        n != f"ecoinvent-{version}-biosphere",
                        n != f"biosphere-{version}",
                        n,
                    )
                )
                row.update(project=project, biosphere=biospheres[0], available=True)
            else:
                row["available"] = False
            cases.append(row)
    (OUTPUT / "manifest.json").write_text(json.dumps(cases, indent=2))
    return cases


def summarize(cases):
    rows = []
    for case in cases:
        path = OUTPUT / (case["id"] + ".json")
        row = (
            json.loads(path.read_text())
            if path.exists()
            else dict(
                case, status="not_available" if not case["available"] else "pending"
            )
        )
        rows.append(row)
    summary = {
        "scope": "Complete metals update; IMAGE SSP2-M 2020 and 2050; compact backend; no scenario DB exports.",
        "code_sha256": {name: hashlib.sha256((ROOT / "premise" / name).read_bytes()).hexdigest() for name in ("metals.py", "metals_resource_boundaries.py")},
        "configuration_sha256": {
            name: hashlib.sha256(
                (ROOT / "premise/data/metals" / name).read_bytes()
            ).hexdigest()
            for name in (
                "activities_mapping.yml",
                "metal_products.yaml",
                "technology_conversion_factors.yaml",
            )
        },
        "counts": dict(Counter(r["status"] for r in rows)),
        "cases": rows,
    }
    (OUTPUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str))
    return summary


def main():
    global OUTPUT, PRIVATE
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", type=Path)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--retry-failed", action="store_true")
    args = parser.parse_args()
    OUTPUT = args.output.resolve()
    PRIVATE = Path("/private/tmp") / OUTPUT.name
    OUTPUT.mkdir(parents=True, exist_ok=True)
    PRIVATE.mkdir(parents=True, exist_ok=True)
    if args.case:
        worker(json.loads(args.case.read_text()))
        return
    cases = discover()
    for case in cases:
        existing = OUTPUT / (case["id"] + ".json")
        if existing.exists() and not (
            args.retry_failed and json.loads(existing.read_text())["status"] == "failed"
        ):
            continue
        if not case["available"]:
            continue
        case_path = PRIVATE / (case["id"] + "-input.json")
        case_path.write_text(json.dumps(case))
        print("CASE START", case["id"], flush=True)
        with (PRIVATE / (case["id"] + ".log")).open("w") as log:
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).resolve()),
                    "--case",
                    str(case_path),
                    "--output",
                    str(OUTPUT),
                ],
                cwd=ROOT,
                stdout=log,
                stderr=subprocess.STDOUT,
                check=False,
            )
        if existing.exists():
            result = json.loads(existing.read_text())
            print(
                "CASE FINISH",
                case["id"],
                result["status"],
                result.get("error", ""),
                flush=True,
            )
        else:
            existing.write_text(
                json.dumps(
                    dict(case, status="failed", error="Worker exited without a result")
                )
            )
            print("CASE FINISH", case["id"], "worker terminated", flush=True)
        summarize(cases)
    print("MATRIX", summarize(cases)["counts"], flush=True)


if __name__ == "__main__":
    main()
