"""Check real inventory preservation, idempotence and agreement with A–G assessment."""

import csv
import hashlib
import json
import pickle
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main():
    import bw2data as bd
    import numpy as np
    import premise.metals as module
    from premise.metals import Metals, METAL_RESOURCE_FLOW_NAMES, get_in_ground_resource_exchanges

    baseline = Path("results/metals-primary-relics-20261020-full")
    assessment = Path("results/metals-resource-fix-assessment-20261020")
    meta = json.loads((baseline / "metadata.json").read_text())
    bd.projects.set_current(meta["project"])
    connection = sqlite3.connect((Path(bd.projects.dir) / "lci/databases.db").as_uri() + "?mode=ro", uri=True)
    database = {code: pickle.loads(raw) for code, raw in connection.execute('SELECT code,data FROM activitydataset WHERE "database"=?', (meta["database"],))}
    bio = {code: pickle.loads(raw) for code, raw in connection.execute('SELECT code,data FROM activitydataset WHERE "database"=?', (meta["biosphere"],))}
    for d in database.values():
        d["exchanges"] = []
    for code, raw in connection.execute("SELECT output_code,data FROM exchangedataset WHERE output_database=?", (meta["database"],)):
        e = pickle.loads(raw)
        if e["type"] == "biosphere":
            b = bio[e["input"][1]]
            e.update({k: b[k] for k in ("name", "categories", "unit")})
        database[code]["exchanges"].append(e)
    lookup = {(d['name'], d['reference product'], d['location']): code for code, d in database.items()}

    def resources():
        return {(code, e['name']): float(e['amount']) for code, d in database.items() for e in get_in_ground_resource_exchanges(d) if e['name'] in METAL_RESOURCE_FLOW_NAMES}

    def other_hash():
        return hashlib.sha256(pickle.dumps([[e for e in d["exchanges"] if not (e.get("type") == "biosphere" and e.get("unit") == "kilogram" and tuple(e.get("categories", ())) == ("natural resource", "in ground") and e.get("name") in METAL_RESOURCE_FLOW_NAMES)] for d in database.values()])).hexdigest()

    expected = resources()
    changes = list(csv.DictReader((assessment / "direct_resource_changes.csv").open()))
    for row in changes:
        code = lookup[row['name'], row['product'], row['location']]
        expected[code, row['element']] = float(row['after_direct_resource'])
    before_other = other_hash()
    metals = object.__new__(Metals)
    metals.database = list(database.values())
    metals.version = "3.12"
    metals.system_model = "cutoff"
    metals._validation_targets = {}
    # Events are exercised in the real build; this check isolates resource math.
    module.record_change_event = lambda *args, **kwargs: None
    metals.post_allocation_correction()
    actual = resources()
    different = []
    for code, element in expected.keys() | actual.keys():
        a, e = actual.get((code, element), 0), expected.get((code, element), 0)
        if not np.isclose(a, e, rtol=1e-9, atol=1e-10):
            d = database[code]
            different.append({'name': d['name'], 'product': d['reference product'], 'location': d['location'], 'element': element, 'expected': e, 'actual': a})
    print("UNEXPECTED", json.dumps(different[:30], indent=2), flush=True)
    print("DIAGNOSTICS", json.dumps(metals.resource_diagnostics[-12:], indent=2), flush=True)
    assert not different, f"{len(different)} resource changes differ from isolated assessment"
    assert other_hash() == before_other
    once = pickle.dumps(metals.database)
    metals.post_allocation_correction()
    assert pickle.dumps(metals.database) == once, "Real inventory is not idempotent"
    assert other_hash() == before_other
    print(json.dumps({'datasets': len(database), 'resource_assignments_checked': len(changes),
                      'agrees_with_isolated_assessment': True, 'all_other_exchanges_unchanged': True,
                      'idempotent': True}), flush=True)


if __name__ == "__main__":
    main()
