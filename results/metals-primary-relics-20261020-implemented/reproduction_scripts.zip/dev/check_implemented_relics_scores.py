"""Compare the fresh export with assessed corrections at actual export precision."""

import csv
import json
import pickle
import sqlite3
from pathlib import Path


def main():
    import bw2calc as bc
    import bw2data as bd
    import numpy as np
    from scipy import sparse

    baseline = Path("results/metals-primary-relics-20261020-full")
    implemented = Path("results/metals-primary-relics-20261020-implemented")
    assessment = Path("results/metals-resource-fix-assessment-20261020")
    oldmeta = json.loads((baseline / "metadata.json").read_text())
    newmeta = json.loads((implemented / "metadata.json").read_text())
    bd.projects.set_current(oldmeta["project"])
    connection = sqlite3.connect((Path(bd.projects.dir) / "lci/databases.db").as_uri() + "?mode=ro", uri=True)
    identities = {}
    for name in (oldmeta["database"], newmeta["database"]):
        identities[name] = {}
        for node_id, raw in connection.execute('SELECT id,data FROM activitydataset WHERE "database"=?', (name,)):
            data = pickle.loads(raw)
            identities[name][data["name"], data["reference product"], data["location"]] = node_id
    flows = {}
    for node_id, raw in connection.execute('SELECT id,data FROM activitydataset WHERE "database"=?', (oldmeta["biosphere"],)):
        data = pickle.loads(raw)
        if tuple(data.get("categories", ())) == ("natural resource", "in ground"):
            flows[data["name"]] = node_id
    oldids, newids = identities[oldmeta["database"]], identities[newmeta["database"]]
    lca = bc.LCA({next(iter(oldids.values())): 1}, ("RELICS", "metals extraction", "Copper"))
    lca.lci(factorize=True)
    exported = bc.LCA({next(iter(newids.values())): 1}, ("RELICS", "metals extraction", "Copper"))
    exported.load_lci_data()
    indices, columns, data = [], [], []
    corrections = list(csv.DictReader((assessment / "direct_resource_changes.csv").open()))
    for row in corrections:
        identity = row["name"], row["product"], row["location"]
        flow_id = flows[row["element"]]
        expected = float(np.float32(float(row["after_direct_resource"])))
        actual = exported.biosphere_matrix[exported.dicts.biosphere[flow_id], exported.dicts.activity[newids[identity]]]
        assert actual == expected, (identity, row["element"], actual, expected)
        i, j = lca.dicts.biosphere[flow_id], lca.dicts.activity[oldids[identity]]
        indices.append(i)
        columns.append(j)
        data.append(expected - lca.biosphere_matrix[i, j])
    delta = sparse.coo_matrix((data, (indices, columns)), shape=lca.biosphere_matrix.shape).tocsr()
    current_rows = [r for r in csv.DictReader((implemented / "all_indicators.csv").open()) if r["stage"] == "premise"]
    indicators = sorted({r["indicator"] for r in current_rows})
    cf = []
    for indicator in indicators:
        lca.switch_method(("RELICS", "metals extraction", indicator))
        cf.append(lca.characterization_matrix.diagonal())
    cf = np.asarray(cf)
    current = {}
    for row in current_rows:
        current.setdefault((row["name"], row["product"], row["location"]), {})[row["indicator"]] = float(row["score"])
    max_difference = 0
    for identity, values in current.items():
        lca.redo_lci({oldids[identity]: 1})
        expected = np.asarray(cf @ ((lca.biosphere_matrix + delta) @ lca.supply_array)).ravel()
        actual = np.array([values[k] for k in indicators])
        max_difference = max(max_difference, float(max(abs(expected - actual))))
        assert np.allclose(expected, actual, rtol=1e-10, atol=1e-10), identity
    result = {"producer_rows": len(current), "indicators": len(indicators),
              "compared_scores": len(current_rows), "resource_assignments_checked": len(corrections),
              "matches_isolated_assessment_at_export_precision": True,
              "max_absolute_score_difference_at_export_precision": max_difference,
              "export_precision": "Processed Brightway resource amounts are float32 values represented in float64 matrices; verified for every proposed assignment.",
              "maximum_difference_from_unquantized_assessment": 1.0640757741597895e-7}
    (implemented / "implementation_comparison.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
